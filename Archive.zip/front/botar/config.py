# config.py
BOT_TOKEN = "7743883203:AAHfyEaYpMRUNWN9T_jrbBd0lWkoqzQHU6k"
API_BASE_URL = "http://127.0.0.1:8000"  # Base URL for conference API
REDIS_DSN = "redis://localhost:6379/0"  # Redis connection string